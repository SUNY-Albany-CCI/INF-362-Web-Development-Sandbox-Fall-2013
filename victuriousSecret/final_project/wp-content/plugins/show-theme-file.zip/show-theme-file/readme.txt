=== Plugin Name ===
Contributors: asdasDan
Tags: theme, file, template, hierarchy
Tested up to: 3.4

This is a simple plugin that uses wordpress' hierarchy to determine what theme file the current page used to render it!

== Installation ==

Installation is quite simple!

1. Upload showThemeFile.php to your wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Browse your website and look at the top for what theme file rendered it! (Must be Admin)
